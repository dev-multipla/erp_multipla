#contas_pagar/serializers.py
from rest_framework import serializers
from django.core.validators import DecimalValidator
from .models import ContaAPagar, ProjetoContaAPagar, ContaAReceber, ProjetoContaAReceber, ContaPagarAvulso, ContaReceberAvulso
from projetos.models import Projeto
from pagamentos.models import FormaPagamento
from contratos.models import Contrato
from financeiro.models import ContaFinanceira, CentroCusto

class ProjetoContaAPagarSerializer(serializers.ModelSerializer):
    projeto = serializers.PrimaryKeyRelatedField(queryset=Projeto.objects.all()) 

    class Meta:
        model = ProjetoContaAPagar
        fields = ['projeto', 'valor']

class ContaAPagarSerializer(serializers.ModelSerializer):
    contrato = serializers.PrimaryKeyRelatedField(queryset=Contrato.objects.all())
    forma_pagamento = serializers.PrimaryKeyRelatedField(queryset=FormaPagamento.objects.all())
    projetos = ProjetoContaAPagarSerializer(many=True)
    avulso = serializers.BooleanField(read_only=True, default=False)
    conta_financeira = serializers.PrimaryKeyRelatedField(queryset=ContaFinanceira.objects.all())
    centro_custo = serializers.PrimaryKeyRelatedField(queryset=CentroCusto.objects.all())

    class Meta:
        model = ContaAPagar
        fields = ['id','contrato', 'forma_pagamento', 'data_pagamento', 'competencia','conta_financeira','centro_custo', 'valor_total', 'projetos', 'avulso']  # Inclua 'avulso' aqui
    
    def validate(self, data):
        instance = self.instance
        contrato = data.get('contrato')
        if not instance or instance.pk is None:
            # Verificar se o contrato já está pago no ProjecaoFaturamento
            vencimentos_pagos = contrato.projecoes_faturamento.filter(pago=True)
            if vencimentos_pagos.exists():
                raise serializers.ValidationError("Este contrato já foi pago anteriormente.")
        return data

    def create(self, validated_data):
        projetos_data = validated_data.pop('projetos')
        conta_a_pagar = ContaAPagar.objects.create(**validated_data)
        for projeto_data in projetos_data:
            ProjetoContaAPagar.objects.create(conta_a_pagar=conta_a_pagar, **projeto_data)
        return conta_a_pagar
    'contrato', 'forma_pagamento', 'data_pagamento', 'competencia', 'valor_total', 'projetos', 'avulso'

    def update(self, instance, validated_data):
        projetos_data = validated_data.pop('projetos')
        instance = super().update(instance, validated_data)

        # Atualizar projetos associados
        instance.projeto_contas_a_pagar.all().delete()
        for projeto_data in projetos_data:
            ProjetoContaAPagar.objects.create(conta_a_pagar=instance, **projeto_data)

        return instance

    def to_representation(self, instance):
        representation = super().to_representation(instance)
        # Serializar os projetos usando o related_name correto
        representation['projetos'] = [
            {'id': projeto.projeto.id, 'nome': projeto.projeto.nome} 
            for projeto in instance.projeto_contas_a_pagar.all()
        ]
        return representation

class ContaPagarAvulsoSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContaPagarAvulso
        fields = '__all__'
        extra_kwargs = {
            'valor': {'validators': [DecimalValidator(max_digits=10, decimal_places=2)]},
        }

class ProjetoContaAReceberSerializer(serializers.ModelSerializer):
    projeto = serializers.PrimaryKeyRelatedField(queryset=Projeto.objects.all()) 

    class Meta:
        model = ProjetoContaAPagar
        fields = ['projeto', 'valor']

class ContaAReceberSerializer(serializers.ModelSerializer):
    contrato = serializers.PrimaryKeyRelatedField(queryset=Contrato.objects.filter(tipo='cliente'))  # Filtra contratos de clientes
    forma_pagamento = serializers.PrimaryKeyRelatedField(queryset=FormaPagamento.objects.all())
    projetos = ProjetoContaAReceberSerializer(many=True)
    avulso = serializers.BooleanField(read_only=True, default=False)
    conta_financeira = serializers.PrimaryKeyRelatedField(queryset=ContaFinanceira.objects.all())
    centro_custo = serializers.PrimaryKeyRelatedField(queryset=CentroCusto.objects.all())

    class Meta:
        model = ContaAReceber
        fields = ['id','contrato', 'forma_pagamento', 'data_recebimento', 'competencia','conta_financeira','centro_custo', 'valor_total', 'projetos', 'avulso']  # Inclua 'avulso' aqui
    
    def validate(self, data):
        # Verificar se o contrato já recebeu em ProjecaoFaturamento
        contrato = data.get('contrato')
        vencimentos_recebidos = contrato.projecoes_faturamento.filter(pago=True)
        if vencimentos_recebidos.exists():
            raise serializers.ValidationError("Este contrato já teve recebimento registrado anteriormente.")
        return data

    def create(self, validated_data):
        projetos_data = validated_data.pop('projetos')
        conta_a_receber = ContaAReceber.objects.create(**validated_data)
        for projeto_data in projetos_data:
            ProjetoContaAReceber.objects.create(conta_a_receber=conta_a_receber, **projeto_data)
        return conta_a_receber

    def update(self, instance, validated_data):
        projetos_data = validated_data.pop('projetos')
        instance = super().update(instance, validated_data)

        # Atualizar projetos associados
        instance.projeto_contas_a_pagar.all().delete()
        for projeto_data in projetos_data:
            ProjetoContaAReceber.objects.create(conta_a_receber=instance, **projeto_data)

        return instance

class ContaReceberAvulsoSerializer(serializers.ModelSerializer):
    class Meta:
        model = ContaReceberAvulso
        fields = '__all__'
        extra_kwargs = {
            'valor': {'validators': [DecimalValidator(max_digits=10, decimal_places=2)]},
        }
    
class RelatorioFinanceiroSerializer(serializers.Serializer):
    contrato_nome = serializers.CharField()
    projeto_nome = serializers.CharField()
    receita = serializers.DecimalField(max_digits=10, decimal_places=2)
    despesa = serializers.DecimalField(max_digits=10, decimal_places=2)
    resultado = serializers.DecimalField(max_digits=10, decimal_places=2)

class ProjecaoMensalSerializer(serializers.Serializer):
    mes = serializers.CharField()
    tipo = serializers.CharField()
    valor_total = serializers.DecimalField(max_digits=10, decimal_places=2)
    valor_pago = serializers.DecimalField(max_digits=10, decimal_places=2)
    valor_aberto = serializers.DecimalField(max_digits=10, decimal_places=2)

class TotaisSerializer(serializers.Serializer):
    total_receber = serializers.DecimalField(max_digits=10, decimal_places=2)
    total_pagar = serializers.DecimalField(max_digits=10, decimal_places=2)
    total_recebido = serializers.DecimalField(max_digits=10, decimal_places=2)
    total_pago = serializers.DecimalField(max_digits=10, decimal_places=2)

class RelatorioProjecoesSerializer(serializers.Serializer):
    relatorio = ProjecaoMensalSerializer(many=True)
    totais = TotaisSerializer()

    def to_representation(self, instance):
        # Este método permite customizar a representação final dos dados
        data = super().to_representation(instance)
        
        # Aqui você pode adicionar lógica adicional se necessário
        # Por exemplo, adicionar campos calculados ou reformatar dados

        return data